ShapeBasedInterpolation
=======================

The shape-based interpolation method described by Raya and Udupa in 1990 for three-dimensional images
